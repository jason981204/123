"""Small JSON save file for persistent coins, shop upgrades and records."""

import json
import os
from pathlib import Path
import shutil
import sys


if os.name == "nt":
    DATA_ROOT = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
else:
    DATA_ROOT = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")

SAVE_PATH = DATA_ROOT / "STARFALL" / "savegame.json"
LEGACY_SAVE_PATHS = [Path(__file__).with_name("savegame.json")]
if getattr(sys, "frozen", False):
    executable_dir = Path(sys.executable).parent
    LEGACY_SAVE_PATHS.extend((
        executable_dir / "savegame.json",
        executable_dir / "_internal" / "savegame.json",
    ))
SHOP_UPGRADE_MAX = {"damage": 3, "hull": 3, "fortune": 5}
WEB_SAVE_KEY = "starfall.savegame"


def _browser_local_storage():
    import platform

    return platform.window.localStorage


class SaveData:
    def __init__(self):
        self.coins = 0
        self.language = "en"
        self.cheat_enabled = False
        self.upgrades = {"damage": 0, "hull": 0, "fortune": 0}
        self.records = {"best_score": 0, "best_wave": 0, "games": 0}
        if sys.platform == "emscripten":
            stored_data = _browser_local_storage().getItem(WEB_SAVE_KEY)
            data = json.loads(str(stored_data)) if stored_data is not None else None
        else:
            if not SAVE_PATH.exists():
                legacy_path = next(
                    (path for path in LEGACY_SAVE_PATHS
                     if path != SAVE_PATH and path.exists()),
                    None
                )
                if legacy_path is not None:
                    SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(legacy_path, SAVE_PATH)
            data = None
            if SAVE_PATH.exists():
                with SAVE_PATH.open("r", encoding="utf-8") as file:
                    data = json.load(file)
        if data is not None:
            self.coins = max(0, int(data.get("coins", 0)))
            self.language = data.get("language", "en")
            if self.language not in ("en", "zh"):
                self.language = "en"
            self.cheat_enabled = bool(data.get("cheat_enabled", False))
            for key in self.upgrades:
                self.upgrades[key] = max(
                    0, min(SHOP_UPGRADE_MAX[key], int(data.get("upgrades", {}).get(key, 0)))
                )
            for key in self.records:
                self.records[key] = max(0, int(data.get("records", {}).get(key, 0)))

    def save(self):
        data = {
            "coins": self.coins,
            "language": self.language,
            "cheat_enabled": self.cheat_enabled,
            "upgrades": self.upgrades,
            "records": self.records,
        }
        if sys.platform == "emscripten":
            _browser_local_storage().setItem(
                WEB_SAVE_KEY, json.dumps(data, ensure_ascii=False)
            )
            return
        SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
        temporary = SAVE_PATH.with_suffix(".tmp")
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
        temporary.replace(SAVE_PATH)

    def add_coins(self, amount):
        self.coins += max(0, int(amount))
        self.save()

    def record_run(self, score, wave):
        self.records["games"] += 1
        self.records["best_score"] = max(self.records["best_score"], int(score))
        self.records["best_wave"] = max(self.records["best_wave"], int(wave))
        self.save()

    def reset_progress(self):
        """重設可遊玩進度，保留玩家的介面語言與作弊模式偏好。"""
        self.coins = 0
        self.upgrades = {"damage": 0, "hull": 0, "fortune": 0}
        self.records = {"best_score": 0, "best_wave": 0, "games": 0}
        self.save()

    def buy_upgrade(self, key, cost):
        if key not in self.upgrades:
            raise KeyError(f"Unknown shop upgrade: {key}")
        if self.coins < cost or self.upgrades[key] >= SHOP_UPGRADE_MAX[key]:
            return False
        self.coins -= cost
        self.upgrades[key] += 1
        self.save()
        return True
