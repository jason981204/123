"""Player, enemy, projectile, boss and visual-effect entities."""

import math
import random

import pygame

from settings import (
    BLUE, CYAN, GREEN, HEIGHT, ORANGE, PURPLE, RED, WHITE, WIDTH, YELLOW
)
from localization import tr
from ui import draw_bar


class Bullet:
    def __init__(self, x, y, vx, vy, damage=1, enemy=False, color=CYAN, pierce=0,
                 delay=0, target_pos=None, signal_id=None):
        self.x, self.y = float(x), float(y)
        self.vx, self.vy = vx, vy
        self.damage, self.enemy, self.color, self.pierce = damage, enemy, color, pierce
        self.delay = delay
        self.target_pos = target_pos
        self.signal_id = signal_id
        self.charging = target_pos is not None
        self.speed = math.hypot(vx, vy)
        self.acceleration = 0.14
        self.hit_ids = set()
        size = 16 if self.charging else (10 if enemy else 6)
        self.rect = pygame.Rect(0, 0, size, size if self.charging or enemy else 18)
        self.rect.center = (round(x), round(y))

    def activate(self):
        """接收 Boss 訊號後，鎖定當初記錄的位置並開始加速。"""
        if not self.charging:
            return
        dx = self.target_pos[0] - self.x
        dy = self.target_pos[1] - self.y
        length = max(1.0, math.hypot(dx, dy))
        self.speed = 0.8
        self.vx = dx / length * self.speed
        self.vy = dy / length * self.speed
        self.charging = False
        self.signal_id = None

    def update(self):
        if self.target_pos is not None:
            if self.charging:
                # 倒數期間維持漂浮，時間到或 Boss 訊號都會啟動追擊。
                self.delay -= 1
                if self.delay <= 0:
                    self.activate()
            else:
                self.speed = min(6.0, self.speed + self.acceleration)
                length = max(1.0, math.hypot(self.vx, self.vy))
                self.vx = self.vx / length * self.speed
                self.vy = self.vy / length * self.speed
        self.x += self.vx
        self.y += self.vy
        self.rect.center = (round(self.x), round(self.y))

    def alive(self):
        return -24 < self.x < WIDTH + 24 and -24 < self.y < HEIGHT + 24

    def draw(self, surface):
        if self.enemy:
            radius = self.rect.width // 2
            if self.charging:
                pulse = 2 if self.delay // 8 % 2 else 0
                glow = tuple(int(channel * 0.30 + base * 0.70)
                             for channel, base in zip(self.color, (13, 19, 39)))
                pygame.draw.circle(surface, glow, self.rect.center, radius + 8 + pulse)
                pygame.draw.circle(surface, self.color, self.rect.center, radius)
                pygame.draw.circle(surface, WHITE, self.rect.center, max(2, radius // 3))
                pygame.draw.circle(surface, WHITE, self.rect.center, radius + 4, 1)
            else:
                pygame.draw.circle(surface, self.color, self.rect.center, radius)
                pygame.draw.circle(surface, WHITE, self.rect.center, max(2, radius // 3))
        else:
            pygame.draw.rect(surface, self.color, self.rect, border_radius=3)
            pygame.draw.rect(surface, WHITE, self.rect.inflate(-3, -7), border_radius=2)


class Player:
    # 玩家強化有硬上限；避免永久升級與關卡升級互相乘算造成失控。
    MAX_DAMAGE = 2.25
    MAX_HP = 10
    MAX_SPEED = 6.5
    MAX_SHOTS = 3
    MAX_PIERCE = 2
    MAX_XP_MULTIPLIER = 1.5

    def __init__(self, bonuses=None, cheat_enabled=False):
        bonuses = bonuses or {}
        self.cheat_enabled = cheat_enabled
        self.rect = pygame.Rect(0, 0, 46, 48)
        self.rect.midbottom = (WIDTH // 2, HEIGHT - 34)
        self.speed = 5.2
        self.max_hp = min(self.MAX_HP, 5 + bonuses.get("hull", 0))
        self.hp = self.max_hp
        self.damage = min(self.MAX_DAMAGE, 1.0 + bonuses.get("damage", 0) * 0.12)
        self.fire_delay = 13
        self.shots = 1
        self.pierce = 0
        self.xp_multiplier = 1.0
        self.coin_multiplier = 1 + bonuses.get("fortune", 0) * 0.15
        self.level = 1
        # 等級上限由關卡波次逐步開放，避免前期過快取得完整成長。
        self.max_level = 5
        self.xp = 0
        self.fire_timer = 0
        self.invulnerable = 0
        self.debuff = None
        self.velocity_x = 0.0
        self.velocity_y = 0.0

    def set_debuff(self, debuff):
        """切換時序 Boss 的負面狀態，避免慣性速度殘留到其他狀態。"""
        self.debuff = debuff
        self.velocity_x = 0.0
        self.velocity_y = 0.0

    @property
    def xp_required(self):
        return 30 + (self.level - 1) * 18

    @property
    def at_level_cap(self):
        return self.level >= self.max_level

    @property
    def hitbox(self):
        return self.rect.inflate(-22, -20)

    def update(self, keys):
        dx = int(keys[pygame.K_RIGHT] or keys[pygame.K_d]) - int(keys[pygame.K_LEFT] or keys[pygame.K_a])
        dy = int(keys[pygame.K_DOWN] or keys[pygame.K_s]) - int(keys[pygame.K_UP] or keys[pygame.K_w])
        if self.debuff == "reverse":
            dx, dy = -dx, -dy
        if dx and dy:
            dx *= 0.7071
            dy *= 0.7071
        if self.debuff == "inertia":
            # 慣性狀態靠方向鍵加速；放開後以低摩擦逐漸滑行。
            self.velocity_x += dx * 0.8
            self.velocity_y += dy * 0.8
            max_speed = self.speed * 1.15
            speed = math.hypot(self.velocity_x, self.velocity_y)
            if speed > max_speed:
                self.velocity_x *= max_speed / speed
                self.velocity_y *= max_speed / speed
            if not dx:
                self.velocity_x *= 0.992
            if not dy:
                self.velocity_y *= 0.992
            self.rect.x += round(self.velocity_x)
            self.rect.y += round(self.velocity_y)
            bounds = pygame.Rect(12, 12, WIDTH - 24, HEIGHT - 24)
            self.rect.clamp_ip(bounds)
            if self.rect.left == bounds.left or self.rect.right == bounds.right:
                self.velocity_x = 0
            if self.rect.top == bounds.top or self.rect.bottom == bounds.bottom:
                self.velocity_y = 0
        else:
            self.rect.x += round(dx * self.speed)
            self.rect.y += round(dy * self.speed)
            self.rect.clamp_ip(pygame.Rect(12, 12, WIDTH - 24, HEIGHT - 24))
        self.fire_timer = max(0, self.fire_timer - 1)
        self.invulnerable = max(0, self.invulnerable - 1)

    def shoot(self):
        if self.fire_timer:
            return []
        self.fire_timer = self.fire_delay
        bullets = []
        damage = self.damage * (3 if self.cheat_enabled else 1)
        for i in range(self.shots):
            offset = i - (self.shots - 1) / 2
            bullets.append(Bullet(
                self.rect.centerx + offset * 14, self.rect.top,
                offset * 1.35, -11, damage, color=CYAN, pierce=self.pierce
            ))
        return bullets

    def draw(self, surface):
        if self.invulnerable and self.invulnerable // 5 % 2:
            return
        x, y = self.rect.center
        hull_color = BLUE if self.debuff == "inertia" else CYAN
        cockpit_color = (164, 205, 255) if self.debuff == "inertia" else WHITE
        pygame.draw.polygon(surface, hull_color, [(x, y - 28), (x - 24, y + 20), (x, y + 11), (x + 24, y + 20)])
        pygame.draw.polygon(surface, cockpit_color, [(x, y - 15), (x - 7, y + 9), (x + 7, y + 9)])
        pygame.draw.polygon(surface, (32, 63, 180) if self.debuff == "inertia" else (24, 83, 128),
                            [(x - 9, y + 21), (x, y + 34), (x + 9, y + 21)])


class Enemy:
    invulnerable = False

    # 基礎生命、尺寸、經驗值與外觀顏色；生命成長倍率在下方統一調整。
    TYPES = {
        "scout": (1.0, 28, 5, RED),
        "gunner": (2.0, 36, 8, ORANGE),
        "tank": (4.0, 46, 12, PURPLE),
    }
    CATALOG = (
        ("SCOUT", "偵察機", "Fast, lightly armored and easy to destroy", "速度快、裝甲薄，容易擊破"),
        ("GUNNER", "砲擊機", "Fires aimed shots while descending", "下降途中會朝玩家發射子彈"),
        ("TANK", "重裝機", "Slow but durable; keep firing", "移動緩慢但耐打，持續攻擊"),
    )

    def __init__(self, wave, kind="scout", position=None):
        base_hp, size, self.xp, self.color = self.TYPES[kind]
        self.kind = kind
        # 讓敵人隨波次變強，但降低曲線斜率，避免中後期生命值暴增。
        self.max_hp = base_hp * (1 + 0.18 * (wave - 1))
        self.hp = self.max_hp
        # 敵人每逢五波增加 1.5% 減傷，最多 30%；套用於最終承受傷害。
        self.damage_reduction = min(0.30, (wave // 5) * 0.015)
        self.xp *= 1 + 0.08 * (wave - 1)
        self.rect = pygame.Rect(0, 0, size, size)
        if position is None:
            self.rect.midtop = (random.randint(size, WIDTH - size), -size)
        else:
            self.rect.center = position
        self.base_x = self.rect.x
        self.y = float(self.rect.y)
        self.speed = random.uniform(1.3, 2.2) + min(wave, 24) * 0.025
        self.phase = random.random() * math.tau
        self.shoot_timer = random.randint(55, 130)
        self.flash = 0

    def update(self, wave):
        self.phase += 0.045
        self.y += self.speed
        self.rect.y = round(self.y)
        self.rect.x = max(0, min(WIDTH - self.rect.width, round(self.base_x + math.sin(self.phase) * 46)))
        self.shoot_timer -= 1
        self.flash = max(0, self.flash - 1)
        if self.kind == "gunner" and self.shoot_timer <= 0 and self.rect.top > 0:
            self.shoot_timer = random.randint(95, 155)
            return Bullet(self.rect.centerx, self.rect.bottom, 0, 4.1 + min(wave, 20) * 0.08,
                          enemy=True, color=YELLOW)
        return None

    def draw(self, surface):
        color = WHITE if self.flash else self.color
        x, y = self.rect.center
        pygame.draw.polygon(surface, color, [(x, y + self.rect.height // 2), (self.rect.left, y - 7), (self.rect.right, y - 7)])
        pygame.draw.circle(surface, (20, 25, 40), (x, y), 5)
        draw_bar(surface, pygame.Rect(self.rect.x, self.rect.y - 9, self.rect.width, 5), self.hp / self.max_hp, GREEN)


class Boss:
    # 首領種類供隨機抽選；描述同時提供給怪物圖鑑使用。
    CATALOG = (
        ("DREADNOUGHT", "無畏戰艦", "Spread cannons and aimed bursts", "扇形砲火與追蹤連射"),
        ("VOID CORE", "虛空核心", "Rotating spiral bullet patterns", "旋轉螺旋彈幕"),
        ("PHANTOM", "幻影戰機", "Aimed volleys and a telegraphed dive", "瞄準連射與蓄力俯衝"),
        ("AEGIS BASTION", "神盾堡壘", "Alternates a frontal shield and volleys", "交替展開護盾與齊射"),
        ("BROODMOTHER", "育巢母艦", "Calls escorts and fires three aimed shots", "召喚護衛並發射三連瞄準彈"),
        ("LANCE WARDEN", "長槍守衛", "Sweeps the arena with a warning laser", "以預警雷射橫掃戰場"),
        ("SPLIT ORB", "分裂核心", "A silent bouncing orb that splits three times", "不會射擊、撞牆反彈並連續分裂三次"),
        ("SIGNAL REAPER", "訊號收割者", "Marks your position before launching a delayed bullet wave", "標記玩家位置後，以延遲訊號引爆彈幕"),
        ("TEMPORAL COMPILER", "時序編譯者", "Every 20 seconds, scans and replaces your active debuff", "每 20 秒掃描並替換一種玩家負面狀態"),
        ("RIFT CARTOGRAPHER", "裂隙測繪者", "Maps shifting safe corridors through descending grid volleys", "以逐排變位的網格彈幕，迫使玩家穿越安全通道"),
        ("PRISM PHANTOM", "稜鏡幻象", "Hides among decoys and fires refracted aimed volleys", "藏身於分身之中，並發射折射瞄準彈幕"),
    )
    COLORS = (ORANGE, GREEN, PURPLE, BLUE, YELLOW, CYAN, (255, 242, 180),
              (255, 105, 220), (110, 180, 255), (100, 235, 220),
              (230, 135, 255))

    def __init__(self, tier, kind=None):
        self.tier = tier
        self.kind = random.randrange(len(self.CATALOG)) if kind is None else kind
        self.color = self.COLORS[self.kind]
        # 每五波一場首領戰；生命緩步成長，讓後續首領更強但仍可擊破。
        self.max_hp = self.hp = 150 + 70 * (tier - 1)
        # 階級提高時逐步增加最終減傷乘區，最高 59.5%。
        self.damage_reduction = min(0.60, 0.12 + (tier - 1) * 0.025)
        self.xp = 100 * tier
        size = 88 if self.kind == 6 else 144
        self.rect = pygame.Rect(0, -100, size, size if self.kind == 6 else 90)
        self.rect.centerx = WIDTH // 2
        self.timer = 0
        self.angle = 0.0
        self.entering = True
        self.flash = 0
        self.dive_state = "hover"
        self.dive_timer = 0
        self.dive_x = WIDTH // 2
        self.laser_state = "idle"
        self.laser_x = WIDTH // 2
        self.laser_origin_x = WIDTH // 2
        self.previous_shielded = False
        self.split_depth = 0
        self.velocity = [2.4, 2.0]
        self.signal_countdown = 0
        self.signal_group_id = None
        self.signal_serial = 0
        self.signal_flash = 0
        self.scan_flash = 0
        self.scan_duration = 48
        self.scan_index = -1
        self.grid_warning = 0
        self.grid_rows_remaining = 0
        self.grid_row_timer = 0
        self.grid_row_index = 0
        self.grid_gap_start = 3
        self.clone_timer = 0
        self.prism_warning = 0
        self.prism_position_index = 1
        if self.kind == 8:
            self.timer = -1

    @property
    def name(self):
        return tr(self.CATALOG[self.kind][0], self.CATALOG[self.kind][1])

    @property
    def description(self):
        return tr(self.CATALOG[self.kind][2], self.CATALOG[self.kind][3])

    @property
    def phase(self):
        ratio = self.hp / self.max_hp
        return 0 if ratio > 0.66 else 1 if ratio > 0.33 else 2

    @property
    def is_split_boss(self):
        return self.kind == 6

    @property
    def shielded(self):
        # 堡壘按固定週期開關護盾；狀態可讀，供碰撞判定與外觀共用。
        return self.kind == 3 and not self.entering and self.timer % 240 < 85

    @property
    def invulnerable(self):
        return self.entering or self.shielded

    @classmethod
    def preview(cls, kind):
        """建立指定種類的圖鑑預覽；不會改變實際首領波次。"""
        return cls(kind + 1, kind)

    def update(self, player, bullets, minions):
        self.flash = max(0, self.flash - 1)
        if self.entering:
            self.rect.y = min(95, self.rect.y + 2)
            self.entering = self.rect.y < 95
            return
        self.timer += 1
        self.signal_flash = max(0, self.signal_flash - 1)
        self.scan_flash = max(0, self.scan_flash - 1)
        if self.is_split_boss:
            # 分裂核心不射擊，只在視窗四邊反彈。
            self.rect.x += round(self.velocity[0])
            self.rect.y += round(self.velocity[1])
            if self.rect.left <= 0 or self.rect.right >= WIDTH:
                self.velocity[0] *= -1
                self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))
            if self.rect.top <= 60 or self.rect.bottom >= HEIGHT:
                self.velocity[1] *= -1
                self.rect.clamp_ip(pygame.Rect(0, 60, WIDTH, HEIGHT - 60))
            return
        phase = self.phase
        self.previous_shielded = self.shielded

        # 1. 無畏戰艦：掃射扇形子彈，低血量時加快並追加追蹤彈。
        if self.kind == 0:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.018) * (WIDTH * 0.36))
            interval = max(34, 76 - phase * 12)
            if self.timer % interval == 0:
                count = 5 + phase
                for i in range(count):
                    angle = math.pi / 2 + (i - (count - 1) / 2) * 0.19
                    bullets.append(Bullet(self.rect.centerx, self.rect.bottom,
                                          math.cos(angle) * 3.2, math.sin(angle) * 3.2,
                                          enemy=True, color=self.color))
            if phase and self.timer % 110 == 0:
                self._aimed_bullet(player, bullets, speed=3.4)

        # 2. 虛空核心：左右移動並交替展開多臂旋轉彈幕。
        elif self.kind == 1:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.012) * (WIDTH * 0.29))
            if self.timer % 11 == 0:
                self.angle += 0.4
                arms = 3 if phase == 0 else 4
                for arm in range(arms):
                    angle = self.angle + arm * math.tau / arms
                    bullets.append(Bullet(self.rect.centerx, self.rect.centery,
                                          math.cos(angle) * 2.8, math.sin(angle) * 2.8,
                                          enemy=True, color=self.color))
        # 3. 幻影戰機：瞄準三連射，先顯示衝刺預警線再俯衝、返航。
        elif self.kind == 2:
            self.dive_timer += 1
            if self.dive_state == "hover":
                self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.015) * 210)
                if self.timer % max(48, 86 - phase * 12) == 0:
                    self._aimed_bullet(player, bullets, speed=3.3, spread=0.16)
                if self.dive_timer >= max(115, 190 - phase * 25):
                    self.dive_state = "warning"
                    self.dive_timer = 0
                    self.dive_x = player.rect.centerx
            elif self.dive_state == "warning":
                if self.dive_timer >= 40:
                    self.dive_state = "dive"
                    self.dive_timer = 0
                    self.rect.centerx = max(75, min(WIDTH - 75, self.dive_x))
            elif self.dive_state == "dive":
                self.rect.y += 8
                if self.rect.top > HEIGHT - 130:
                    self.dive_state = "return"
            else:
                self.rect.y = max(95, self.rect.y - 5)
                if self.rect.top <= 95:
                    self.dive_state = "hover"
                    self.dive_timer = 0

        # 4. 神盾堡壘：護盾期間免疫傷害，關盾後以瞄準砲反擊。
        elif self.kind == 3:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.009) * 145)
            if self.timer % 95 == 0 and not self.shielded:
                self._aimed_bullet(player, bullets, speed=3.1, spread=0.14)
                if phase:
                    self._aimed_bullet(player, bullets, speed=3.1, spread=-0.14)

        # 5. 育巢母艦：週期性放出護衛，並向玩家位置散射卵艙彈幕。
        elif self.kind == 4:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.01) * 180)
            if self.timer % 175 == 0:
                minions.extend((
                    Enemy(max(1, self.tier * 5), "gunner", (self.rect.left, self.rect.bottom)),
                    Enemy(max(1, self.tier * 5), "scout", (self.rect.right, self.rect.bottom)),
                ))
            if self.timer % 82 == 0:
                self._aimed_bullet(player, bullets, speed=2.7, spread=0.22, count=3)

        # 6. 長槍守衛：雷射先預警再啟動，掃描位置持續橫移。
        elif self.kind == 5:
            self.rect.centerx = WIDTH // 2
            cycle = self.timer % 200
            if cycle < 55:
                self.laser_state = "idle"
            elif cycle < 85:
                self.laser_state = "warning"
                if cycle == 55:
                    self.laser_origin_x = player.rect.centerx
                self.laser_x = self.laser_origin_x
            else:
                self.laser_state = "active"
                self.laser_x = round(
                    self.laser_origin_x
                    + math.sin((cycle - 85) * (0.075 + phase * 0.015)) * 240
                )
                self.laser_x = max(24, min(WIDTH - 24, self.laser_x))
            if cycle in (55, 125) and phase:
                self._aimed_bullet(player, bullets, speed=3.0)

        # 7. 訊號收割者：佈下靜止光彈，短暫預警後集體追向玩家原位置。
        elif self.kind == 7:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.008) * 170)
            if self.timer % 230 == 15:
                self.signal_serial += 1
                self.signal_group_id = self.signal_serial
                self.signal_countdown = 100
                target_pos = player.rect.center
                for index in range(7):
                    x = WIDTH * (index + 1) / 8
                    y = self.rect.bottom + 58 + (index % 2) * 22
                    drift = -0.12 if index % 2 else 0.12
                    bullets.append(Bullet(
                        x, y, drift, 0.08, enemy=True, color=self.color,
                        delay=210, target_pos=target_pos,
                        signal_id=self.signal_group_id
                    ))
            if self.signal_countdown:
                self.signal_countdown -= 1
                if self.signal_countdown == 0:
                    for bullet in bullets:
                        if bullet.signal_id == self.signal_group_id:
                            bullet.activate()
                    self.signal_flash = 22

        # 8. 時序編譯者：戰鬥第 0 秒與每 20 秒掃描，替換玩家負面狀態。
        elif self.kind == 8:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.006) * 125)
            # 每六秒一輪低速三連瞄準彈，與掃描狀態切換分開，留足閃避空間。
            if self.timer > 0 and self.timer % (6 * 60) == 0:
                self._aimed_bullet(player, bullets, speed=2.7, spread=0.20, count=3)
            if self.timer % (20 * 60) == 0:
                statuses = ("reverse", "inertia", "double_damage")
                player.set_debuff(None)
                self.scan_index = (self.scan_index + 1) % len(statuses)
                player.set_debuff(statuses[self.scan_index])
                self.scan_flash = self.scan_duration

        # 9. 裂隙測繪者：以有安全缺口的分排彈幕，逐步改變玩家可走的路線。
        elif self.kind == 9:
            self.rect.centerx = round(WIDTH / 2 + math.sin(self.timer * 0.007) * 145)
            if self.timer % 360 == 1:
                self.grid_warning = 45
                self.grid_rows_remaining = 0
                self.grid_row_index = 0
                self.grid_gap_start = max(
                    0, min(7, round((player.rect.centerx - 70) / 102.5) - 1)
                )
            if self.grid_warning:
                self.grid_warning -= 1
                if self.grid_warning == 0:
                    self._fire_grid_row(bullets, phase)
                    self.grid_rows_remaining = 2 if phase < 2 else 3
                    self.grid_row_timer = 32
                    self.grid_row_index = 1
            elif self.grid_rows_remaining:
                self.grid_row_timer -= 1
                if self.grid_row_timer <= 0:
                    self._fire_grid_row(bullets, phase)
                    self.grid_rows_remaining -= 1
                    self.grid_row_timer = 32
                    self.grid_row_index += 1

        # 10. 稜鏡幻象：分身只作視覺誘餌，真身仍可受傷並發射扇形瞄準彈。
        elif self.kind == 10:
            anchors = (WIDTH // 4, WIDTH // 2, WIDTH * 3 // 4)
            if self.timer % 420 == 1:
                self.prism_warning = 30
            if self.prism_warning:
                self.prism_warning -= 1
                if self.prism_warning == 0:
                    self.prism_position_index = (
                        self.prism_position_index + 1
                    ) % len(anchors)
                    self.clone_timer = 120
            if self.clone_timer:
                self.clone_timer -= 1
                self.rect.center = (anchors[self.prism_position_index], 145)
            else:
                self.rect.centerx = round(
                    WIDTH / 2 + math.sin(self.timer * 0.009) * 190
                )
            interval = 210 if phase == 0 else 180
            count = 5 if phase == 2 else 3
            if self.timer % interval == 0:
                self._aimed_bullet(
                    player, bullets, speed=2.7, spread=0.20, count=count
                )

    def _fire_grid_row(self, bullets, phase):
        gap_start = self._grid_gap_for_row(self.grid_row_index, phase)
        y = self.rect.bottom + 12
        for lane in range(9):
            if gap_start <= lane < gap_start + 2:
                continue
            x = 70 + lane * 102.5
            bullets.append(Bullet(
                x, y, 0, 2.6, enemy=True, color=self.color
            ))

    def _grid_gap_for_row(self, row_index, phase):
        gap_shift = row_index if phase == 2 else int(row_index >= 2)
        return max(0, min(7, self.grid_gap_start + gap_shift))

    def split_children(self):
        """核心被擊破時生成兩顆小核心；最多分裂三層。"""
        if not self.is_split_boss or self.split_depth >= 3:
            return []
        child_radius = max(12, self.rect.width // 3)
        children = []
        for direction in (-1, 1):
            child = SplitOrb(self.tier, self.split_depth + 1, child_radius)
            child.rect.center = (
                self.rect.centerx + direction * child_radius,
                self.rect.centery
            )
            child.velocity = [direction * (2.5 + self.split_depth * 0.35),
                              -2.0 if direction < 0 else 2.0]
            children.append(child)
        return children

    @property
    def encounter_max_hp(self):
        if not self.is_split_boss:
            return self.max_hp
        total = self.max_hp
        for depth in range(1, 4):
            total += (2 ** depth) * max(8, 34 // (2 ** depth) + self.tier * 3)
        return total

    def _aimed_bullet(self, player, bullets, speed, spread=0.0, count=1):
        # 共用的瞄準彈幕工具，降低不同首領的重複計算。
        dx = player.rect.centerx - self.rect.centerx
        dy = player.rect.centery - self.rect.bottom
        angle = math.atan2(dy, dx)
        offsets = (0,) if count == 1 else tuple((i - (count - 1) / 2) * spread for i in range(count))
        for offset in offsets:
            shot_angle = angle + offset
            bullets.append(Bullet(
                self.rect.centerx, self.rect.bottom,
                math.cos(shot_angle) * speed, math.sin(shot_angle) * speed,
                enemy=True, color=self.color
            ))

    def laser_hits(self, player):
        return (self.kind == 5 and self.laser_state == "active"
                and player.rect.top < HEIGHT
                and player.rect.bottom > self.rect.bottom
                and abs(player.rect.centerx - self.laser_x) < 19)

    def draw(self, surface):
        x, y = self.rect.center
        color = WHITE if self.flash else self.color
        if self.is_split_boss:
            radius = self.rect.width // 2
            pygame.draw.circle(surface, color, (x, y), radius)
            pygame.draw.circle(surface, (17, 22, 38), (x, y), radius, 3)
            pygame.draw.circle(surface, WHITE, (x, y), max(3, radius // 3))
            pygame.draw.circle(surface, CYAN, (x, y), max(2, radius // 6))
            return
        if self.kind == 10 and self.clone_timer:
            anchors = (WIDTH // 4, WIDTH // 2, WIDTH * 3 // 4)
            for index, anchor_x in enumerate(anchors):
                if index == self.prism_position_index:
                    continue
                ghost_points = self._prism_points(anchor_x, 145)
                pygame.draw.polygon(surface, (52, 65, 103), ghost_points)
                pygame.draw.polygon(surface, (111, 143, 205), ghost_points, 2)
                pygame.draw.polygon(
                    surface, (111, 143, 205),
                    [(anchor_x, 130), (anchor_x + 12, 145),
                     (anchor_x, 160), (anchor_x - 12, 145)], 2
                )
        if self.kind == 1:
            points = [(x + math.cos(i * math.pi / 3) * 72, y + math.sin(i * math.pi / 3) * 44) for i in range(6)]
        elif self.kind == 2:
            points = [(x, self.rect.bottom), (self.rect.left, y - 30), (x, y + 8), (self.rect.right, y - 30)]
        elif self.kind == 3:
            points = [(self.rect.left, y - 28), (x - 47, self.rect.top), (x + 47, self.rect.top),
                      (self.rect.right, y - 28), (x + 48, self.rect.bottom), (x - 48, self.rect.bottom)]
        elif self.kind == 4:
            points = [(x, self.rect.top), (self.rect.right, y - 8), (x + 43, self.rect.bottom),
                      (x, y + 22), (x - 43, self.rect.bottom), (self.rect.left, y - 8)]
        elif self.kind == 5:
            points = [(x, self.rect.top), (x + 22, y - 10), (x + 12, self.rect.bottom),
                      (x, y + 15), (x - 12, self.rect.bottom), (x - 22, y - 10)]
        elif self.kind == 7:
            points = [(x, self.rect.top), (x + 48, y), (x, self.rect.bottom), (x - 48, y)]
        elif self.kind == 8:
            points = [(x, self.rect.top), (x + 48, y - 30), (x + 34, y + 28),
                      (x, self.rect.bottom), (x - 34, y + 28), (x - 48, y - 30)]
        elif self.kind == 9:
            points = [(x - 58, y - 30), (x - 22, self.rect.top),
                      (x + 22, self.rect.top), (x + 58, y - 30),
                      (x + 42, self.rect.bottom), (x - 42, self.rect.bottom)]
        elif self.kind == 10:
            points = self._prism_points(x, y)
        else:
            points = [(self.rect.left, y - 24), (x - 50, self.rect.top), (x + 50, self.rect.top),
                      (self.rect.right, y - 24), (x + 25, self.rect.bottom), (x - 25, self.rect.bottom)]
        pygame.draw.polygon(surface, color, points)
        pygame.draw.polygon(surface, (17, 22, 38), points, 3)
        pygame.draw.circle(surface, RED if self.hp / self.max_hp < 0.34 else CYAN, (x, y), 11)
        if self.shielded:
            pygame.draw.ellipse(surface, CYAN, self.rect.inflate(26, 20), 3)
        if self.kind == 2 and self.dive_state == "warning":
            pygame.draw.line(surface, RED, (self.dive_x, self.rect.bottom), (self.dive_x, HEIGHT), 3)
        if self.kind == 3 and not self.shielded:
            pygame.draw.circle(surface, WHITE, (x, y), 20, 2)
        if self.kind == 4:
            pygame.draw.circle(surface, ORANGE, (x, y + 8), 13, 2)
        if self.kind == 5 and self.laser_state != "idle":
            laser_color = RED if self.laser_state == "warning" else ORANGE
            width = 2 if self.laser_state == "warning" else 14
            pygame.draw.line(surface, laser_color, (self.laser_x, self.rect.bottom),
                             (self.laser_x, HEIGHT), width)
        if self.kind == 7 and self.signal_countdown:
            radius = 72 + (self.timer // 4 % 8) * 3
            pygame.draw.circle(surface, self.color, (x, y), radius, 2)
            if self.signal_countdown < 35:
                pygame.draw.circle(surface, WHITE, (x, y), radius + 7, 1)
        if self.kind == 7 and self.signal_flash:
            pygame.draw.circle(surface, WHITE, (x, y), 84, 3)
        if self.kind == 8:
            pygame.draw.circle(surface, self.color, (x, y), 50, 2)
            pygame.draw.circle(surface, WHITE, (x, y), 10 + self.timer % 8, 2)
            if self.scan_flash:
                pygame.draw.circle(surface, WHITE, (x, y), 70, 3)
        if self.kind == 9:
            pygame.draw.line(surface, WHITE, (x - 28, y), (x + 28, y), 2)
            if self.grid_warning:
                preview_rows = 4 if self.phase == 2 else 3
                for row_index in range(preview_rows):
                    gap_start = self._grid_gap_for_row(row_index, self.phase)
                    left = round(70 + gap_start * 102.5 - 45)
                    right = round(70 + (gap_start + 2) * 102.5 - 45)
                    pygame.draw.line(surface, self.color, (left, self.rect.bottom + 20),
                                     (left, HEIGHT), 1)
                    pygame.draw.line(surface, self.color, (right, self.rect.bottom + 20),
                                     (right, HEIGHT), 1)
        if self.kind == 10:
            pygame.draw.polygon(
                surface, WHITE,
                [(x, y - 16), (x + 13, y), (x, y + 16), (x - 13, y)]
            )
            if self.prism_warning:
                pygame.draw.circle(surface, WHITE, (x, y), 58, 2)

    @staticmethod
    def _prism_points(x, y):
        return [(x, y - 45), (x + 52, y - 12), (x + 38, y + 34),
                (x, y + 45), (x - 38, y + 34), (x - 52, y - 12)]


class SplitOrb:
    """分裂核心的小型子體：純碰撞威脅，無射擊能力。"""

    invulnerable = False
    is_split_boss = True

    def __init__(self, tier, depth, radius):
        self.tier = tier
        self.split_depth = depth
        self.color = CYAN if depth < 3 else WHITE
        self.rect = pygame.Rect(0, 0, radius * 2, radius * 2)
        self.max_hp = self.hp = max(8, 34 // (2 ** depth) + tier * 3)
        self.damage_reduction = min(0.60, 0.12 + (tier - 1) * 0.025)
        self.xp = 0
        self.flash = 0
        self.velocity = [2.5, 2.0]

    def update(self, player, bullets, minions):
        self.flash = max(0, self.flash - 1)
        self.rect.x += round(self.velocity[0])
        self.rect.y += round(self.velocity[1])
        if self.rect.left <= 0 or self.rect.right >= WIDTH:
            self.velocity[0] *= -1
            self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))
        if self.rect.top <= 60 or self.rect.bottom >= HEIGHT:
            self.velocity[1] *= -1
            self.rect.clamp_ip(pygame.Rect(0, 60, WIDTH, HEIGHT - 60))

    def split_children(self):
        if self.split_depth >= 3:
            return []
        radius = max(8, self.rect.width // 3)
        children = []
        for direction in (-1, 1):
            child = SplitOrb(self.tier, self.split_depth + 1, radius)
            child.rect.center = (self.rect.centerx + direction * radius, self.rect.centery)
            child.velocity = [direction * (2.6 + self.split_depth * 0.4),
                              -2.0 if direction < 0 else 2.0]
            children.append(child)
        return children

    def draw(self, surface):
        color = WHITE if self.flash else self.color
        radius = self.rect.width // 2
        pygame.draw.circle(surface, color, self.rect.center, radius)
        pygame.draw.circle(surface, (17, 22, 38), self.rect.center, radius, 2)
        pygame.draw.circle(surface, CYAN, self.rect.center, max(2, radius // 3))


class Particle:
    def __init__(self, position, color):
        self.x, self.y = position
        angle, speed = random.random() * math.tau, random.uniform(1, 4)
        self.vx, self.vy = math.cos(angle) * speed, math.sin(angle) * speed
        self.life = random.randint(16, 32)
        self.color = color

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (round(self.x), round(self.y)), max(1, self.life // 9))
