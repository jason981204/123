"""English and Traditional Chinese interface strings."""

LANGUAGES = ("en", "zh")
_language = "en"


def set_language(language):
    global _language
    if language not in LANGUAGES:
        raise ValueError(f"Unsupported language: {language}")
    _language = language


def get_language():
    return _language


def tr(english, chinese):
    return chinese if _language == "zh" else english
