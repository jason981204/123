"""Reusable drawing helpers and clickable buttons."""

from pathlib import Path
import sys

import pygame

from settings import CYAN, MUTED, PANEL, PANEL_LIGHT, WHITE

pygame.font.init()
_cjk_font = pygame.font.match_font(
    "microsoftjhenghei,msjh,notosanscjk,simhei,microsoftyahei,arialunicode"
)
_bundled_cjk_font = Path(__file__).with_name("StarfallCJK.ttf")


def get_font(size, bold=False):
    if sys.platform == "emscripten" and _bundled_cjk_font.exists():
        return pygame.font.Font(str(_bundled_cjk_font), size)
    return pygame.font.Font(_cjk_font, size) if _cjk_font else pygame.font.SysFont(
        "arial", size, bold=bold
    )


FONT_SMALL = get_font(17)
FONT = get_font(22)
FONT_MEDIUM = get_font(30)
FONT_LARGE = get_font(58, True)
FONT_HUGE = get_font(76, True)


def draw_text(surface, text, font, color, position, anchor="center"):
    image = font.render(str(text), True, color)
    surface.blit(image, image.get_rect(**{anchor: position}))


def draw_panel(surface, rect, color=PANEL, border=CYAN, radius=18):
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    pygame.draw.rect(surface, (*border, 95), rect, 1, border_radius=radius)


def draw_bar(surface, rect, ratio, color, background=(39, 48, 73)):
    pygame.draw.rect(surface, background, rect, border_radius=max(2, rect.height // 2))
    fill = rect.copy()
    fill.width = max(0, min(rect.width, round(rect.width * ratio)))
    if fill.width:
        pygame.draw.rect(surface, color, fill, border_radius=max(2, rect.height // 2))


class Button:
    def __init__(self, rect, label, action, accent=CYAN):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.action = action
        self.accent = accent

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.action()
                return True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            if self.rect.collidepoint(pygame.mouse.get_pos()):
                self.action()
                return True
        return False

    def draw(self, surface):
        hovered = self.rect.collidepoint(pygame.mouse.get_pos())
        fill = PANEL_LIGHT if hovered else PANEL
        shadow = self.rect.move(0, 4)
        pygame.draw.rect(surface, (3, 6, 16), shadow, border_radius=12)
        pygame.draw.rect(surface, fill, self.rect, border_radius=12)
        border = self.accent if hovered else (48, 69, 105)
        pygame.draw.rect(surface, border, self.rect, 2, border_radius=12)
        pygame.draw.rect(surface, border, (self.rect.x + 2, self.rect.y + 10, 3, self.rect.h - 20),
                         border_radius=2)
        draw_text(surface, self.label, FONT_SMALL if self.rect.w < 200 else FONT,
                  WHITE if hovered else MUTED, self.rect.center)


def draw_top_grid(surface, color=(19, 33, 60), spacing=48):
    width, height = surface.get_size()
    for x in range(0, width, spacing):
        pygame.draw.line(surface, color, (x, 0), (x, height), 1)
    for y in range(0, height, spacing):
        pygame.draw.line(surface, color, (0, y), (width, y), 1)


def draw_stars(surface, stars):
    surface.fill((7, 11, 28))
    for x, y, radius in stars:
        brightness = 54 + radius * 24
        pygame.draw.circle(surface, (brightness, brightness, min(255, brightness + 35)), (x, y), radius)
