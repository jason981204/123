"""Wave progression, combat, leveling, score and in-run rendering."""

import random

import pygame

from entities import Boss, Bullet, Enemy, Particle, Player
from localization import tr
from settings import (
    BG, BLUE, CYAN, GREEN, HEIGHT, MUTED, ORANGE, PANEL, PURPLE, RED,
    WHITE, WIDTH, YELLOW
)
from ui import FONT, FONT_SMALL, draw_bar, draw_text
from upgrades import choose_three


class GameSession:
    def __init__(self, permanent_upgrades=None, previous_boss_kind=None,
                 boss_challenge_kind=None, cheat_enabled=False):
        self.stars = [
            [random.randrange(WIDTH), random.randrange(HEIGHT), random.choice((1, 1, 2, 3))]
            for _ in range(110)
        ]
        self.player = Player(permanent_upgrades, cheat_enabled)
        self.player_bullets = []
        self.enemy_bullets = []
        self.enemies = []
        self.particles = []
        self.boss = None
        self.boss_parts = []
        # 從上一局接續 Boss 種類，避免重新開局後連續遇到相同首領。
        self.last_boss_kind = previous_boss_kind
        self.mode = "boss_challenge" if boss_challenge_kind is not None else "campaign"
        self.boss_challenge_kind = boss_challenge_kind
        self.wave = 0
        self.score = 0
        self.coins_earned = 0
        self.kills = 0
        self.bosses_defeated = 0
        self.to_spawn = 0
        self.spawn_timer = 0
        self.banner_timer = 0
        self.banner = ""
        self.state = "playing"
        self.pending_upgrades = 0
        self.choices = []
        self.start_wave()

    def start_wave(self):
        self.wave += 1
        if self.mode == "boss_challenge":
            # 挑戰模式直接進入指定首領戰，不生成一般敵人或後續波次。
            self.wave = 5
            self.player.max_level = 6
            self.boss = Boss(1, self.boss_challenge_kind)
            self.boss_parts = [self.boss]
            self.last_boss_kind = self.boss_challenge_kind
            self.to_spawn = 0
            self.banner_timer = 130
            self.banner = tr(f"BOSS CHALLENGE // {self.boss.name}",
                             f"首領挑戰 // {self.boss.name}")
            self.spawn_timer = 24
            return
        # 初始等級上限 5；每跨過五波開放一級，100 波時上限為 25。
        self.player.max_level = 5 + self.wave // 5
        self.enemy_bullets.clear()
        self.banner_timer = 130
        # 每五波安排首領戰；非首領波的敵人數量採溫和成長。
        if self.wave % 5 == 0:
            # 隨機出場且盡量避免連續兩場同一種類。
            choices = [kind for kind in range(len(Boss.CATALOG))
                       if kind != self.last_boss_kind]
            boss_kind = random.choice(choices)
            self.boss = Boss(self.wave // 5, boss_kind)
            self.last_boss_kind = boss_kind
            self.boss_parts = [self.boss]
            self.to_spawn = 0
            self.banner = tr(f"ELITE SIGNATURE // WAVE {self.wave}", f"特殊首領 // 第 {self.wave} 波")
        else:
            self.boss = None
            self.boss_parts = []
            self.to_spawn = 5 + self.wave
            self.banner = tr(f"WAVE {self.wave}", f"第 {self.wave} 波")
        self.spawn_timer = 24

    def available_enemy_kind(self):
        roll = random.random()
        if self.wave >= 4 and roll < 0.18:
            return "tank"
        if self.wave >= 2 and roll < 0.48:
            return "gunner"
        return "scout"

    def award_xp(self, amount):
        player = self.player
        if player.at_level_cap:
            player.xp = min(player.xp, player.xp_required - 1)
            return
        player.xp += amount * player.xp_multiplier
        while player.xp >= player.xp_required and player.level < player.max_level:
            player.xp -= player.xp_required
            player.level += 1
            self.pending_upgrades += 1
        # 上限期間只保留不到升級所需的經驗，避免囤積後一次跳過多級。
        if player.at_level_cap:
            player.xp = min(player.xp, player.xp_required - 1)

    def open_upgrade(self):
        self.choices = choose_three(self.player)
        if self.choices:
            self.state = "levelup"
        else:
            self.pending_upgrades = 0
            self.state = "playing"

    def choose_upgrade(self, index):
        if self.state != "levelup" or not 0 <= index < len(self.choices):
            return
        self.choices[index].apply(self.player)
        self.pending_upgrades -= 1
        if self.pending_upgrades:
            self.open_upgrade()
        else:
            self.state = "playing"

    def spawn_burst(self, position, color, count=12):
        self.particles.extend(Particle(position, color) for _ in range(count))

    def damage_player(self):
        if self.player.cheat_enabled or self.player.invulnerable:
            return
        damage = 2 if self.player.debuff == "double_damage" else 1
        self.player.hp -= damage
        self.player.invulnerable = 80
        self.spawn_burst(self.player.rect.center, CYAN, 22)
        if self.player.hp <= 0:
            self.state = "gameover"

    def destroy_target(self, target):
        self.spawn_burst(target.rect.center, target.color, 34 if target is self.boss else 14)
        self.kills += 1
        reward = 0
        if target in self.boss_parts:
            # 分裂小球不額外送完整 Boss 獎勵；全部清除後才結算一次。
            self.award_xp(target.xp)
            self.boss_parts.remove(target)
            children = target.split_children()
            self.boss_parts.extend(children)
            self.spawn_burst(target.rect.center, target.color, 20 if children else 12)
            if not self.boss_parts:
                root = self.boss
                reward = int(120 * root.tier * self.player.coin_multiplier)
                self.score += 1000 * root.tier
                self.bosses_defeated += 1
                if root.kind == 8:
                    self.player.set_debuff(None)
                self.boss = None
                self.enemy_bullets.clear()
                if self.mode == "boss_challenge":
                    self.state = "victory"
        else:
            self.award_xp(target.xp)
            reward = int((3 + self.wave // 3) * self.player.coin_multiplier)
            self.score += int(target.xp * 2)
            if target in self.enemies:
                self.enemies.remove(target)
        if reward:
            self.coins_earned += reward

    def update(self, keys):
        for star in self.stars:
            star[1] += star[2]
            if star[1] > HEIGHT:
                star[0], star[1] = random.randrange(WIDTH), 0
        if self.state != "playing":
            return
        if self.pending_upgrades:
            self.open_upgrade()
            return

        self.player.update(keys)
        if keys[pygame.K_SPACE]:
            self.player_bullets.extend(self.player.shoot())
        if self.banner_timer:
            self.banner_timer -= 1
        elif self.to_spawn:
            self.spawn_timer -= 1
            if self.spawn_timer <= 0:
                self.enemies.append(Enemy(self.wave, self.available_enemy_kind()))
                self.to_spawn -= 1
                self.spawn_timer = max(16, 54 - self.wave)

        for bullet in self.player_bullets + self.enemy_bullets:
            bullet.update()
        for enemy in self.enemies:
            shot = enemy.update(self.wave)
            if shot:
                self.enemy_bullets.append(shot)
        if self.boss:
            minions = []
            self.boss.update(self.player, self.enemy_bullets, minions)
            for part in self.boss_parts:
                if part is not self.boss:
                    part.update(self.player, self.enemy_bullets, minions)
            self.enemies.extend(minions)
        for particle in self.particles:
            particle.update()

        self.collide_player_bullets()
        self.collide_with_player()
        self.player_bullets[:] = [b for b in self.player_bullets if b.alive()]
        self.enemy_bullets[:] = [b for b in self.enemy_bullets if b.alive()]
        self.particles[:] = [p for p in self.particles if p.life > 0]
        self.enemies[:] = [enemy for enemy in self.enemies if enemy.rect.top < HEIGHT]

        if (self.state == "playing" and self.banner_timer == 0 and not self.to_spawn
                and not self.enemies and not self.boss_parts):
            self.player.hp = min(self.player.max_hp, self.player.hp + 1)
            self.start_wave()

    def collide_player_bullets(self):
        for bullet in self.player_bullets[:]:
            targets = self.enemies[:] + self.boss_parts[:]
            for target in targets:
                if (target is None or target.hp <= 0 or target.invulnerable
                        or id(target) in bullet.hit_ids
                        or not bullet.rect.colliderect(target.rect)):
                    continue
                bullet.hit_ids.add(id(target))
                # 減傷作為最後承傷乘區，避免直接稀釋玩家攻擊力面板。
                target.hp -= bullet.damage * (1 - target.damage_reduction)
                target.flash = 4
                self.spawn_burst(bullet.rect.center, WHITE, 3)
                if target.hp <= 0:
                    self.destroy_target(target)
                if bullet.pierce:
                    bullet.pierce -= 1
                else:
                    if bullet in self.player_bullets:
                        self.player_bullets.remove(bullet)
                    break

    def collide_with_player(self):
        hitbox = self.player.hitbox
        for bullet in self.enemy_bullets[:]:
            if bullet.rect.colliderect(hitbox):
                self.enemy_bullets.remove(bullet)
                self.damage_player()
        for enemy in self.enemies[:]:
            if enemy.rect.colliderect(hitbox):
                self.damage_player()
                self.enemies.remove(enemy)
                self.spawn_burst(enemy.rect.center, enemy.color)
        for boss_part in self.boss_parts:
            if not boss_part.invulnerable and boss_part.rect.colliderect(hitbox):
                self.damage_player()
        if self.boss and self.boss.laser_hits(self.player):
            self.damage_player()

    def draw(self, surface):
        surface.fill(BG)
        for x, y, radius in self.stars:
            color = (54 + radius * 24, 76 + radius * 22, 111 + radius * 25)
            pygame.draw.circle(surface, color, (x, y), radius)
        for bullet in self.player_bullets + self.enemy_bullets:
            bullet.draw(surface)
        for enemy in self.enemies:
            enemy.draw(surface)
        for boss_part in self.boss_parts:
            boss_part.draw(surface)
        for particle in self.particles:
            particle.draw(surface)
        if self.state != "gameover":
            self.player.draw(surface)
        if self.boss and self.boss.kind == 8 and self.boss.scan_flash:
            self.draw_temporal_scan(surface)
        self.draw_hud(surface)
        if self.banner_timer and self.state == "playing":
            draw_text(surface, self.banner, FONT, RED if self.wave % 5 == 0 else WHITE,
                      (WIDTH // 2, 134))

    def draw_hud(self, surface):
        player = self.player
        pygame.draw.rect(surface, (20, 29, 52), (0, 0, WIDTH, 58))
        xp_ratio = 1 if player.at_level_cap else player.xp / player.xp_required
        draw_bar(surface, pygame.Rect(0, 0, WIDTH, 7), xp_ratio, BLUE)
        level_text = (tr(f"LV {player.level}  //  MAX {player.max_level}",
                         f"等級 {player.level}  //  上限 {player.max_level}")
                      if player.at_level_cap else
                      tr(f"LV {player.level}  //  {int(player.xp)} / {player.xp_required}",
                         f"等級 {player.level}  //  {int(player.xp)} / {player.xp_required}"))
        draw_text(surface, level_text,
                  FONT_SMALL, WHITE, (WIDTH // 2, 31))
        draw_text(surface, tr(f"SCORE  {self.score:,}", f"分數  {self.score:,}"), FONT, WHITE, (24, 34), "midleft")
        draw_text(surface, tr(f"WAVE  {self.wave:02d}", f"波次  {self.wave:02d}"), FONT, CYAN, (WIDTH - 24, 34), "midright")
        draw_bar(surface, pygame.Rect(WIDTH - 242, 70, 190, 13),
                 player.hp / player.max_hp, GREEN)
        draw_text(surface, tr(f"HULL {player.hp}/{player.max_hp}", f"裝甲 {player.hp}/{player.max_hp}"),
                  FONT_SMALL, WHITE, (WIDTH - 24, 104), "topright")
        draw_text(surface, tr(f"+{self.coins_earned} CR", f"+{self.coins_earned} 金幣"),
                  FONT_SMALL, YELLOW, (24, 75), "topleft")
        if player.debuff or (self.boss and self.boss.kind == 8):
            status_names = {
                "reverse": tr("REVERSED CONTROLS", "方向相反"),
                "inertia": tr("INERTIAL FLIGHT", "慣性飛行"),
                "double_damage": tr("DOUBLE DAMAGE TAKEN", "受到雙倍傷害"),
            }
            current_status = status_names.get(player.debuff, tr("NONE", "無"))
            status_rect = pygame.Rect(18, 116, 315, 30)
            pygame.draw.rect(surface, (13, 27, 54), status_rect, border_radius=8)
            pygame.draw.rect(surface, (68, 112, 174), status_rect, 1, border_radius=8)
            draw_text(surface, tr(f"DEBUFF  //  {current_status}",
                                  f"目前負面狀態  //  {current_status}"),
                      FONT_SMALL, (160, 205, 255), (28, status_rect.centery), "midleft")
        if player.cheat_enabled:
            draw_text(surface, tr("CHEAT MODE  //  ON", "作弊模式  //  開啟"),
                      FONT_SMALL, YELLOW, (WIDTH - 18, 130), "topright")
        if self.boss:
            draw_text(surface, tr(f"{self.boss.name}  //  TIER {self.boss.tier}",
                                  f"{self.boss.name}  //  階級 {self.boss.tier}")
                      + tr(f"  //  ARMOR {self.boss.damage_reduction:.0%}",
                           f"  //  減傷 {self.boss.damage_reduction:.0%}"),
                      FONT_SMALL, self.boss.color, (WIDTH // 2, 82))
            remaining_hp = sum(part.hp for part in self.boss_parts)
            total_hp = self.boss.encounter_max_hp
            draw_bar(surface, pygame.Rect(110, 97, WIDTH - 220, 12),
                     remaining_hp / max(1, total_hp), self.boss.color, (67, 33, 48))

    def draw_temporal_scan(self, surface):
        """以全寬掃描光帶提示負面狀態已被重新編譯。"""
        progress = 1 - self.boss.scan_flash / self.boss.scan_duration
        scan_y = round(progress * HEIGHT)
        band = pygame.Surface((WIDTH, 38), pygame.SRCALPHA)
        pygame.draw.rect(band, (90, 165, 255, 24), (0, 0, WIDTH, 38))
        pygame.draw.line(band, (155, 215, 255, 210), (0, 19), (WIDTH, 19), 3)
        surface.blit(band, (0, scan_y - 19))
