"""Three-choice run upgrades offered whenever the pilot levels up."""

from dataclasses import dataclass
import random


@dataclass(frozen=True)
class Upgrade:
    name: str
    description: str
    apply: object
    name_zh: str
    description_zh: str
    available: object


def _increase_damage(player):
    player.damage = min(player.MAX_DAMAGE, player.damage + 0.15)


def _increase_fire_rate(player):
    player.fire_delay = max(8, player.fire_delay - 1)


def _add_shot(player):
    player.shots = min(player.MAX_SHOTS, player.shots + 1)


def _add_pierce(player):
    player.pierce = min(player.MAX_PIERCE, player.pierce + 1)


def _increase_xp(player):
    player.xp_multiplier = min(player.MAX_XP_MULTIPLIER, player.xp_multiplier + 0.1)


def _increase_speed(player):
    player.speed = min(player.MAX_SPEED, player.speed + 0.25)


UPGRADES = [
    Upgrade("Overcharged Rounds", "Damage +0.15 (max 2.25)", _increase_damage,
            "超載彈藥", "傷害 +0.15（上限 2.25）", lambda p: p.damage < p.MAX_DAMAGE),
    Upgrade("Rapid Fire", "Cooldown -1 (min 8)", _increase_fire_rate,
            "高速連射", "射擊間隔 -1（最低 8）", lambda p: p.fire_delay > 8),
    Upgrade("Twin Cannons", "One extra shot (max 3)", _add_shot,
            "雙聯砲", "每次多發一枚（最多 3 枚）", lambda p: p.shots < p.MAX_SHOTS),
    Upgrade("Piercing Bolts", "Pierce +1 (max 2)", _add_pierce,
            "穿甲彈", "穿透數 +1（最多 2）", lambda p: p.pierce < p.MAX_PIERCE),
    Upgrade("Reinforced Hull", "Maximum HP +1, heal 2", lambda p: _reinforce(p),
            "強化裝甲", "最大生命 +1，並恢復 2 點", lambda p: p.max_hp < p.MAX_HP),
    Upgrade("Emergency Repair", "Restore 3 HP", lambda p: setattr(p, "hp", min(p.max_hp, p.hp + 3)),
            "緊急維修", "恢復 3 點生命", lambda p: p.hp < p.max_hp),
    Upgrade("Neural Interface", "XP gain +0.1 (max x1.5)", _increase_xp,
            "神經介面", "經驗獲得 +0.1 倍（上限 1.5 倍）",
            lambda p: p.xp_multiplier < p.MAX_XP_MULTIPLIER),
    Upgrade("Ion Thrusters", "Speed +0.25 (max 6.5)", _increase_speed,
            "離子推進器", "移動速度 +0.25（上限 6.5）", lambda p: p.speed < p.MAX_SPEED),
]


def _reinforce(player):
    player.max_hp = min(player.MAX_HP, player.max_hp + 1)
    player.hp = min(player.max_hp, player.hp + 2)


def choose_three(player):
    """只抽取仍能生效的強化，避免升級卡反覆出現卻沒有收益。"""
    available = [upgrade for upgrade in UPGRADES if upgrade.available(player)]
    return random.sample(available, min(3, len(available)))
