"""Shared game settings."""

WIDTH = 960
HEIGHT = 720
FPS = 60
TITLE = "STARFALL // Space Defense"

BG = (7, 11, 28)
PANEL = (16, 25, 50)
PANEL_LIGHT = (24, 39, 72)
WHITE = (235, 244, 255)
MUTED = (142, 162, 193)
CYAN = (73, 224, 255)
BLUE = (87, 130, 255)
GREEN = (83, 230, 160)
YELLOW = (255, 207, 87)
ORANGE = (255, 139, 86)
RED = (255, 91, 112)
PURPLE = (194, 117, 255)
