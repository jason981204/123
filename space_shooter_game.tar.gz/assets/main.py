"""Launch the Starfall space shooter."""

import asyncio
import sys
import pygame

from save_data import SaveData
from screens import SpaceShooterApp
from settings import FPS, HEIGHT, TITLE, WIDTH


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(TITLE)
    clock = pygame.time.Clock()
    app = SpaceShooterApp(screen, SaveData())
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                app.handle_event(event)
        app.update()
        app.draw()
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
    if sys.platform != "emscripten":
        pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())