"""Application screens: main menu, game HUD overlays, shop and records."""

import random

import pygame

from entities import Boss, Enemy
from game import GameSession
from localization import get_language, set_language, tr
from settings import (
    BG, BLUE, CYAN, GREEN, HEIGHT, MUTED, ORANGE, PANEL, PANEL_LIGHT,
    PURPLE, RED, WHITE, WIDTH, YELLOW
)
from ui import (
    Button, FONT, FONT_HUGE, FONT_LARGE, FONT_MEDIUM, FONT_SMALL,
    draw_bar, draw_panel, draw_stars, draw_text, draw_top_grid
)


SHOP_ITEMS = (
    ("damage", "PLASMA AMPLIFIER", "Permanent damage +0.12 (max 3 ranks)",
     "電漿增幅器", "永久傷害 +0.12（最多 3 級）", 100, 3),
    ("hull", "TITANIUM HULL", "Start each run with +1 max HP (max 3)",
     "鈦合金裝甲", "每局最大生命 +1（最多 3 級）", 120, 3),
    ("fortune", "SALVAGE SCANNER", "Earn 15% more coins per rank (max 5)",
     "殘骸掃描器", "每級額外獲得 15% 金幣（最多 5 級）", 140, 5),
)
SHOP_MAX_RANKS = {item[0]: item[6] for item in SHOP_ITEMS}


class SpaceShooterApp:
    def __init__(self, screen, save):
        self.screen = screen
        self.save = save
        set_language(save.language)
        self.page = "menu"
        self.session = None
        self.last_boss_kind = None
        self.buttons = []
        self.return_page = "menu"
        self.challenge_kind = None
        self.message = ""
        self.message_timer = 0
        self.confirm_reset = False
        self.codex_page = 0
        self.ticks = 0
        self.stars = [
            [random.randrange(WIDTH), random.randrange(HEIGHT), random.choice((1, 1, 2, 3))]
            for _ in range(125)
        ]
        # 圖鑑圖示只建立一次，避免每幀重複建立精靈與離屏畫布。
        self.codex_previews = self.create_codex_previews()
        self.build_buttons()

    def set_page(self, page):
        if page == "codex" and self.page != "codex":
            self.codex_page = 0
        self.page = page
        self.build_buttons()

    def build_buttons(self):
        self.buttons = []
        if self.confirm_reset:
            self.buttons = [
                Button((WIDTH // 2 - 180, 400, 165, 52),
                       tr("RESET DATA", "歸零資料"), self.reset_progress, RED),
                Button((WIDTH // 2 + 15, 400, 165, 52),
                       tr("CANCEL", "取消"), self.cancel_reset, CYAN),
            ]
            return
        if self.page != "playing":
            language_label = "中文" if get_language() == "en" else "EN"
            self.buttons.append(Button(
                (WIDTH - 126, 22, 94, 38), language_label, self.toggle_language, YELLOW
            ))
        if self.page == "menu":
            cheat_label = tr(
                f"CHEAT MODE  //  {'ON' if self.save.cheat_enabled else 'OFF'}",
                f"作弊模式  //  {'開啟' if self.save.cheat_enabled else '關閉'}"
            )
            self.buttons.extend([
                Button((570, 286, 310, 44), tr("LAUNCH MISSION", "開始任務"), self.start_game, CYAN),
                Button((570, 334, 310, 42), tr("BOSS CHALLENGE", "Boss 挑戰"),
                       lambda: self.set_page("boss_select"), RED),
                Button((570, 380, 310, 40), cheat_label, self.toggle_cheat_mode,
                       YELLOW if self.save.cheat_enabled else MUTED),
                Button((570, 424, 310, 40), tr("ARMORY  //  SHOP", "裝備庫  //  商店"), lambda: self.set_page("shop")),
                Button((570, 468, 310, 40), tr("MONSTER CODEX", "怪物圖鑑"), lambda: self.set_page("codex"), PURPLE),
                Button((570, 512, 310, 40), tr("FLIGHT MANUAL", "飛行手冊"), lambda: self.set_page("help")),
                Button((570, 556, 310, 40), tr("PILOT RECORD", "飛行紀錄"), lambda: self.set_page("records")),
                Button((570, 600, 310, 36), tr("EXIT", "離開遊戲"), self.quit_game),
            ])
        elif self.page in ("playing", "levelup"):
            pass
        elif self.page == "pause":
            self.buttons.extend([
                    Button((WIDTH // 2 - 135, 340, 270, 50), tr("RESUME  [ P ]", "繼續遊戲  [ P ]"), lambda: self.set_page("playing"), CYAN),
                    Button((WIDTH // 2 - 135, 403, 270, 48), tr("RESTART MISSION", "重新開始"), self.start_game),
                    Button((WIDTH // 2 - 135, 464, 270, 48), tr("VISIT ARMORY", "前往商店"), self.open_shop),
                    Button((WIDTH // 2 - 135, 525, 270, 48), tr("MAIN MENU", "返回主選單"), lambda: self.set_page("menu")),
                ])
        elif self.page == "gameover":
            self.buttons.extend([
                Button((WIDTH // 2 - 140, 450, 280, 50), tr("TRY AGAIN", "再次出擊"),
                       self.retry_current_run, CYAN),
                Button((WIDTH // 2 - 140, 514, 280, 48), tr("MAIN MENU", "返回主選單"), lambda: self.set_page("menu")),
            ])
        elif self.page == "victory":
            self.buttons.extend([
                Button((WIDTH // 2 - 150, 450, 300, 50), tr("FIGHT AGAIN", "再次挑戰"),
                       lambda: self.start_boss_challenge(self.challenge_kind), CYAN),
                Button((WIDTH // 2 - 150, 514, 300, 48), tr("CHOOSE ANOTHER BOSS", "選擇其他 Boss"),
                       lambda: self.set_page("boss_select")),
                Button((WIDTH // 2 - 150, 572, 300, 44), tr("MAIN MENU", "返回主選單"),
                       lambda: self.set_page("menu")),
            ])
        elif self.page == "shop":
            self.buttons.append(Button((36, HEIGHT - 72, 170, 46), tr("BACK", "返回"), self.close_shop))
            for index, (key, _, _, _, _, base_cost, max_rank) in enumerate(SHOP_ITEMS):
                level = self.save.upgrades[key]
                cost = base_cost * (level + 1)
                label = tr("MAX LEVEL", "已達最高級") if level >= max_rank else tr(
                    f"PURCHASE  //  {cost} CR", f"購買  //  {cost} 金幣"
                )
                self.buttons.append(Button(
                    (WIDTH - 280, 216 + index * 140, 230, 48), label,
                    lambda key=key, cost=cost: self.purchase(key, cost),
                    YELLOW if level < 5 else GREEN
                ))
        elif self.page in ("help", "records"):
            self.buttons.append(Button((36, HEIGHT - 72, 170, 46), tr("BACK", "返回"),
                                       lambda: self.set_page("menu")))
            if self.page == "records":
                self.buttons.append(Button(
                    (WIDTH // 2 - 150, 560, 300, 46),
                    tr("RESET SAVE DATA", "存檔資料歸零"),
                    self.ask_reset, RED
                ))
        elif self.page == "codex":
            page_count = self.codex_page_count()
            self.codex_page = max(0, min(self.codex_page, page_count - 1))
            self.buttons.extend([
                Button((36, HEIGHT - 72, 170, 46), tr("BACK", "返回"),
                       lambda: self.set_page("menu")),
                Button((WIDTH // 2 - 180, HEIGHT - 72, 160, 46),
                       tr("PREVIOUS", "上一頁"), self.previous_codex_page),
                Button((WIDTH // 2 + 20, HEIGHT - 72, 160, 46),
                       tr("NEXT", "下一頁"), self.next_codex_page),
            ])
        elif self.page == "boss_select":
            self.buttons.append(Button((36, HEIGHT - 72, 170, 46), tr("BACK", "返回"),
                                       lambda: self.set_page("menu")))
            card_w, card_h, gap_x, gap_y = 270, 90, 18, 12
            start_x, start_y = 57, 150
            for kind, details in enumerate(Boss.CATALOG):
                col, row = kind % 3, kind // 3
                rect = (start_x + col * (card_w + gap_x),
                        start_y + row * (card_h + gap_y), card_w, card_h)
                self.buttons.append(Button(
                    rect, tr(details[0], details[1]),
                    lambda kind=kind: self.start_boss_challenge(kind),
                    Boss.COLORS[kind]
                ))

    def codex_entries(self):
        entries = [("enemy", kind, details) for kind, details in enumerate(Enemy.CATALOG)]
        entries.extend(("boss", kind, details) for kind, details in enumerate(Boss.CATALOG))
        return entries

    def codex_page_count(self):
        return max(1, (len(self.codex_entries()) + 5) // 6)

    def previous_codex_page(self):
        self.codex_page = max(0, self.codex_page - 1)
        self.build_buttons()

    def next_codex_page(self):
        self.codex_page = min(self.codex_page_count() - 1, self.codex_page + 1)
        self.build_buttons()

    def toggle_language(self):
        language = "zh" if get_language() == "en" else "en"
        set_language(language)
        self.save.language = language
        self.save.save()
        self.build_buttons()

    def toggle_cheat_mode(self):
        self.save.cheat_enabled = not self.save.cheat_enabled
        self.save.save()
        self.build_buttons()

    def start_game(self):
        self.session = GameSession(
            self.save.upgrades, self.last_boss_kind,
            cheat_enabled=self.save.cheat_enabled
        )
        self.synced_coins = 0
        self.set_page("playing")

    def start_boss_challenge(self, kind):
        self.challenge_kind = kind
        self.last_boss_kind = kind
        self.session = GameSession(
            self.save.upgrades,
            self.last_boss_kind,
            boss_challenge_kind=kind,
            cheat_enabled=self.save.cheat_enabled
        )
        self.synced_coins = 0
        self.set_page("playing")

    def retry_current_run(self):
        if self.session and self.session.mode == "boss_challenge":
            self.start_boss_challenge(self.challenge_kind)
        else:
            self.start_game()

    def open_shop(self):
        self.return_page = "pause"
        self.set_page("shop")

    def close_shop(self):
        destination = self.return_page
        self.return_page = "menu"
        self.set_page(destination)

    def purchase(self, key, cost):
        if self.save.buy_upgrade(key, cost):
            self.message = tr("UPGRADE INSTALLED", "強化已安裝")
        elif self.save.upgrades[key] >= SHOP_MAX_RANKS[key]:
            self.message = tr("MAXIMUM RANK REACHED", "已達最高級")
        else:
            self.message = tr("NOT ENOUGH CREDITS", "金幣不足")
        self.message_timer = 100
        self.build_buttons()

    def ask_reset(self):
        self.confirm_reset = True
        self.build_buttons()

    def cancel_reset(self):
        self.confirm_reset = False
        self.build_buttons()

    def reset_progress(self):
        self.save.reset_progress()
        self.confirm_reset = False
        self.message = tr("SAVE DATA RESET", "存檔資料已歸零")
        self.message_timer = 150
        self.build_buttons()

    @staticmethod
    def quit_game():
        pygame.event.post(pygame.event.Event(pygame.QUIT))

    def handle_event(self, event):
        if self.confirm_reset:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.cancel_reset()
                return
            for button in self.buttons:
                if button.handle_event(event):
                    return
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.page == "playing":
                    self.set_page("pause")
                elif self.page == "pause":
                    self.set_page("playing")
                elif self.page in ("shop", "help", "records", "boss_select"):
                    self.close_shop() if self.page == "shop" else self.set_page("menu")
                elif self.page in ("victory", "gameover"):
                    self.set_page("menu")
                elif self.page == "menu":
                    self.quit_game()
                return
            if event.key == pygame.K_p and self.page == "playing":
                self.set_page("pause")
                return
            if self.page == "codex" and event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                if event.key == pygame.K_LEFT:
                    self.previous_codex_page()
                else:
                    self.next_codex_page()
                return
            if self.page == "levelup" and pygame.K_1 <= event.key <= pygame.K_3:
                self.select_upgrade(event.key - pygame.K_1)
                return
            if self.page == "gameover" and event.key == pygame.K_r:
                self.retry_current_run()
                return
        if self.page == "levelup" and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for index, rect in enumerate(self.upgrade_rects()):
                if rect.collidepoint(event.pos):
                    self.select_upgrade(index)
                    return
        for button in self.buttons:
            if button.handle_event(event):
                return

    def select_upgrade(self, index):
        self.session.choose_upgrade(index)
        self.set_page("levelup" if self.session.state == "levelup" else "playing")

    def upgrade_rects(self):
        width, gap, height = 260, 20, 250
        left = (WIDTH - (3 * width + 2 * gap)) // 2
        return [pygame.Rect(left + i * (width + gap), 258, width, height) for i in range(3)]

    def update(self):
        self.ticks += 1
        for star in self.stars:
            star[1] += star[2] * 0.45
            if star[1] > HEIGHT:
                star[0], star[1] = random.randrange(WIDTH), 0
        if self.message_timer:
            self.message_timer -= 1
        if self.page in ("playing", "levelup") and self.session:
            if self.page == "playing":
                self.session.update(pygame.key.get_pressed())
                self.last_boss_kind = self.session.last_boss_kind
                difference = self.session.coins_earned - self.synced_coins
                if difference:
                    self.save.add_coins(difference)
                    self.synced_coins += difference
                if self.session.state == "gameover":
                    self.save.record_run(self.session.score, self.session.wave)
                    self.set_page("gameover")
                elif self.session.state == "victory":
                    self.save.record_run(self.session.score, self.session.wave)
                    self.set_page("victory")
                elif self.session.state == "levelup":
                    self.set_page("levelup")

    def draw(self):
        if self.page in ("playing", "levelup", "pause", "gameover", "victory") and self.session:
            self.session.draw(self.screen)
        else:
            draw_stars(self.screen, self.stars)
            draw_top_grid(self.screen, (12, 24, 45), 64)
        if self.page == "menu":
            self.draw_menu()
        elif self.page == "shop":
            self.draw_shop()
        elif self.page == "help":
            self.draw_help()
        elif self.page == "records":
            self.draw_records()
        elif self.page == "codex":
            self.draw_codex()
        elif self.page == "levelup":
            self.draw_levelup()
        elif self.page == "pause":
            self.draw_pause()
        elif self.page == "gameover":
            self.draw_gameover()
        elif self.page == "victory":
            self.draw_victory()
        elif self.page == "boss_select":
            self.draw_boss_select()
        for button in self.buttons:
            button.draw(self.screen)
        if self.page == "boss_select":
            self.draw_boss_select_details()
        if self.confirm_reset:
            self.draw_reset_confirmation()
            for button in self.buttons:
                button.draw(self.screen)
        if self.message_timer:
            draw_text(self.screen, self.message, FONT_SMALL, YELLOW, (WIDTH // 2, HEIGHT - 105))

    def draw_menu(self):
        draw_panel(self.screen, pygame.Rect(62, 115, 448, 535), (10, 17, 37), (47, 90, 138), 26)
        draw_text(self.screen, "S T A R F A L L", FONT_HUGE, WHITE, (286, 224))
        draw_text(self.screen, tr("SPACE DEFENSE", "星際防衛"), FONT_MEDIUM, CYAN, (286, 285))
        pygame.draw.line(self.screen, (44, 75, 120), (118, 330), (454, 330), 2)
        draw_text(self.screen, tr("PILOT // 07", "駕駛員 // 07"), FONT_SMALL, MUTED, (286, 369))
        draw_panel(self.screen, pygame.Rect(116, 416, 340, 78), PANEL_LIGHT, (45, 70, 111), 14)
        draw_text(self.screen, tr("AVAILABLE CREDITS", "可用金幣"), FONT_SMALL, MUTED, (286, 440))
        draw_text(self.screen, tr(f"{self.save.coins:,} CR", f"{self.save.coins:,} 金幣"),
                  FONT_MEDIUM, YELLOW, (286, 470))
        draw_text(self.screen, tr("BOSS SIGNAL DETECTED EVERY 5 WAVES",
                                  "每五波將遭遇特殊首領"), FONT_SMALL, MUTED, (286, 558))
        draw_text(self.screen, tr("MISSION SELECT", "選擇任務"), FONT_MEDIUM, WHITE, (725, 247))
        draw_text(self.screen, tr("CHOOSE YOUR NEXT OPERATION", "選擇接下來的行動"),
                  FONT_SMALL, MUTED, (725, 275))

    def draw_boss_select(self):
        draw_text(self.screen, tr("BOSS CHALLENGE", "Boss 挑戰"),
                  FONT_LARGE, WHITE, (WIDTH // 2, 68))
        draw_text(self.screen, tr("SELECT AN ELITE TO FIGHT",
                                  "選擇一位首領開始挑戰"),
                  FONT_SMALL, CYAN, (WIDTH // 2, 108))

    def draw_boss_select_details(self):
        for kind, details in enumerate(Boss.CATALOG):
            col, row = kind % 3, kind // 3
            x = 57 + col * 288
            y = 150 + row * 102
            draw_text(self.screen, f"ELITE  //  {kind + 1:02d}",
                      FONT_SMALL, Boss.COLORS[kind], (x + 14, y + 10), "topleft")
            description = tr(details[2], details[3])
            lines = self.wrap_codex_text(description, FONT_SMALL, 246)
            for line_index, line in enumerate(lines[:2]):
                draw_text(self.screen, line, FONT_SMALL, MUTED,
                          (x + 16, y + 56 + line_index * 17), "topleft")

    def draw_victory(self):
        self.draw_overlay(
            tr("BOSS DEFEATED", "首領擊破"),
            tr(f"{self.session.bosses_defeated} ELITE CLEARED  //  SCORE {self.session.score:,}",
               f"擊敗首領 {self.session.bosses_defeated} 隻  //  分數 {self.session.score:,}")
        )

    def draw_codex(self):
        """以敵人實際向量外型呈現圖鑑，並列出中英文戰鬥情報。"""
        draw_text(self.screen, tr("THREAT DATABASE", "敵方威脅圖鑑"),
                  FONT_LARGE, WHITE, (WIDTH // 2, 58))
        draw_text(self.screen, tr("FIELD INTELLIGENCE // ENEMIES & ELITES",
                                  "戰場情報 // 一般敵人與特殊首領"),
                  FONT_SMALL, CYAN, (WIDTH // 2, 99))
        entries = self.codex_entries()
        page_count = self.codex_page_count()
        first_entry = self.codex_page * 6
        page_entries = entries[first_entry:first_entry + 6]

        # 三欄卡片保持一致尺寸，方便快速比較敵種與首領機制。
        card_w, card_h, gap_x, gap_y = 292, 160, 14, 14
        start_x, start_y = 23, 126
        for index, (category, kind, details) in enumerate(page_entries):
            col, row = index % 3, index // 3
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            rect = pygame.Rect(x, y, card_w, card_h)
            accent = RED if category == "enemy" else Boss.COLORS[kind]
            draw_panel(self.screen, rect, (12, 20, 42), accent, 15)
            draw_text(self.screen, f"{first_entry + index + 1:02d}", FONT_SMALL, accent,
                      (x + 14, y + 13), "topleft")
            self.draw_codex_preview(category, kind, x + 12, y + 43)

            name = tr(details[0], details[1])
            description = tr(details[2], details[3])
            draw_text(self.screen, name, FONT_SMALL, WHITE, (x + 100, y + 19), "topleft")
            lines = self.wrap_codex_text(description, FONT_SMALL, card_w - 112)
            for line_index, line in enumerate(lines[:2]):
                draw_text(self.screen, line, FONT_SMALL, MUTED,
                          (x + 100, y + 49 + line_index * 21), "topleft")
            if category == "enemy":
                enemy_type = tuple(Enemy.TYPES.values())[kind]
                stat_en = f"HP {enemy_type[0]:g} base  //  XP {enemy_type[2]}"
                stat_zh = f"基礎生命 {enemy_type[0]:g}  //  經驗 {enemy_type[2]}"
                category_text = tr("DR +1.5% / 5 WAVES", "每五波減傷 +1.5%")
            else:
                stat_en = "BOSS  //  HP SCALES BY TIER"
                stat_zh = "首領  //  生命隨階級成長"
                category_text = tr("DAMAGE REDUCTION 12% - 59.5%", "減傷 12% - 59.5%")
            draw_text(self.screen, category_text, FONT_SMALL, accent,
                      (x + 100, y + 101), "topleft")
            draw_text(self.screen, tr(stat_en, stat_zh), FONT_SMALL, WHITE,
                      (x + 100, y + 128), "topleft")
        draw_text(self.screen, tr(f"PAGE {self.codex_page + 1} / {page_count}  //  USE ARROW KEYS",
                                  f"第 {self.codex_page + 1} / {page_count} 頁  //  可用方向鍵翻頁"),
                  FONT_SMALL, MUTED, (WIDTH // 2, 602))

    @staticmethod
    def wrap_codex_text(text, font, max_width):
        """依字型實際寬度自動換行，支援中英文圖鑑說明。"""
        words = list(text) if " " not in text else text.split()
        separator = "" if " " not in text else " "
        lines, current = [], ""
        for word in words:
            candidate = current + separator + word if current else word
            if font.size(candidate)[0] <= max_width:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines

    def draw_codex_preview(self, category, kind, x, y):
        self.screen.blit(self.codex_previews[(category, kind)], (x, y))

    @staticmethod
    def create_codex_previews():
        """預先繪製敵人與 Boss 圖示，讓圖鑑頁維持穩定幀率。"""
        previews = {}
        for kind, enemy_kind in enumerate(Enemy.TYPES):
            preview = pygame.Surface((100, 90), pygame.SRCALPHA)
            Enemy(1, enemy_kind, (50, 45)).draw(preview)
            previews[("enemy", kind)] = pygame.transform.smoothscale(preview, (64, 56))
        for kind in range(len(Boss.CATALOG)):
            preview = pygame.Surface((150, 100), pygame.SRCALPHA)
            boss = Boss.preview(kind)
            boss.rect.center = (75, 50)
            boss.entering = False
            boss.timer = 100
            boss.laser_state = "idle"
            boss.draw(preview)
            previews[("boss", kind)] = pygame.transform.smoothscale(preview, (84, 56))
        return previews

    def draw_shop(self):
        draw_text(self.screen, tr("ARMORY", "裝備庫"), FONT_LARGE, WHITE, (WIDTH // 2, 76))
        draw_text(self.screen, tr("PERMANENT SHIP SYSTEMS", "永久飛船強化"), FONT_SMALL, CYAN, (WIDTH // 2, 124))
        draw_text(self.screen, tr(f"AVAILABLE  {self.save.coins:,} CR",
                                  f"可用金幣  {self.save.coins:,}"), FONT, YELLOW, (WIDTH // 2, 165))
        for index, (key, name, description, name_zh, description_zh, _, max_rank) in enumerate(SHOP_ITEMS):
            y = 216 + index * 140
            rect = pygame.Rect(135, y, 690, 112)
            draw_panel(self.screen, rect)
            draw_text(self.screen, tr(name, name_zh), FONT, WHITE, (rect.x + 25, rect.y + 23), "topleft")
            draw_text(self.screen, tr(description, description_zh), FONT_SMALL, MUTED, (rect.x + 25, rect.y + 57), "topleft")
            level = self.save.upgrades[key]
            draw_text(self.screen, tr(f"RANK  {level} / {max_rank}", f"等級  {level} / {max_rank}"),
                      FONT_SMALL, CYAN, (rect.x + 25, rect.y + 85), "topleft")

    def draw_help(self):
        draw_text(self.screen, tr("FLIGHT MANUAL", "飛行手冊"), FONT_LARGE, WHITE, (WIDTH // 2, 88))
        draw_panel(self.screen, pygame.Rect(145, 165, 670, 440))
        lines = [
            (tr("MOVE", "移動"), tr("WASD or ARROW KEYS", "WASD 或方向鍵")),
            (tr("FIRE", "射擊"), tr("HOLD SPACE", "按住空白鍵")),
            (tr("PAUSE", "暫停"), tr("P or ESC", "P 或 ESC")),
            (tr("LEVEL UP", "升級"), tr("CHOOSE ONE OF THREE UPGRADES", "從三個強化選項中擇一")),
            (tr("OBJECTIVE", "目標"), tr("SURVIVE WAVES AND DEFEAT THE ELITE", "持續生存並擊敗首領")),
            (tr("BOSS", "首領"), tr("A UNIQUE BOSS ARRIVES EVERY 5 WAVES", "每五波出現特殊首領")),
            (tr("LEVEL CAP", "等級上限"), tr("+1 EVERY 5 WAVES; STARTS AT 5", "初始為 5，每五波 +1")),
            (tr("ENEMY ARMOR", "敵方減傷"), tr("ENEMIES GAIN ARMOR EVERY 5 WAVES", "敵人每五波增加減傷")),
            (tr("CODEX", "圖鑑"), tr("READ ABOUT ENEMY TYPES AND BOSS ATTACKS", "查看敵種、首領外型與攻擊機制")),
            (tr("TEMPORAL BOSS", "時序首領"), tr("SCANS EVERY 20 SECONDS AND CYCLES DEBUFFS", "每 20 秒掃描並輪替負面狀態")),
            (tr("CREDITS", "金幣"), tr("DESTROY ENEMIES, THEN BUY PERMANENT GEAR", "擊敗敵人賺取金幣，購買永久強化")),
        ]
        for index, (label, detail) in enumerate(lines):
            y = 190 + index * 39
            draw_text(self.screen, label, FONT_SMALL, CYAN, (190, y), "midleft")
            draw_text(self.screen, detail, FONT_SMALL, WHITE, (390, y), "midleft")

    def draw_records(self):
        draw_text(self.screen, tr("PILOT RECORD", "飛行紀錄"), FONT_LARGE, WHITE, (WIDTH // 2, 105))
        draw_panel(self.screen, pygame.Rect(210, 190, 540, 340))
        rows = (
            (tr("BEST SCORE", "最高分數"), f"{self.save.records['best_score']:,}"),
            (tr("BEST WAVE", "最高波次"), str(self.save.records["best_wave"])),
            (tr("MISSIONS FLOWN", "出擊次數"), str(self.save.records["games"])),
            (tr("CURRENT CREDITS", "目前金幣"), tr(f"{self.save.coins:,} CR", f"{self.save.coins:,}")),
        )
        for index, (label, value) in enumerate(rows):
            y = 255 + index * 66
            draw_text(self.screen, label, FONT, MUTED, (260, y), "midleft")
            draw_text(self.screen, value, FONT, YELLOW if index == 3 else WHITE, (700, y), "midright")

    def draw_reset_confirmation(self):
        """以確認對話框攔截操作，避免誤按清除存檔。"""
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((2, 5, 14, 220))
        self.screen.blit(overlay, (0, 0))
        rect = pygame.Rect(WIDTH // 2 - 245, 220, 490, 300)
        draw_panel(self.screen, rect, PANEL, RED, 20)
        draw_text(self.screen, tr("RESET SAVE DATA?", "確定將存檔資料歸零？"),
                  FONT_MEDIUM, RED, (WIDTH // 2, 285))
        draw_text(self.screen, tr("Coins, upgrades and records will be erased.",
                                  "金幣、永久強化與紀錄都會清除。"),
                  FONT_SMALL, WHITE, (WIDTH // 2, 335))
        draw_text(self.screen, tr("This action cannot be undone.",
                                  "此操作無法復原。"),
                  FONT_SMALL, MUTED, (WIDTH // 2, 365))

    def draw_overlay(self, title, subtitle=None):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 205))
        self.screen.blit(overlay, (0, 0))
        draw_panel(self.screen, pygame.Rect(WIDTH // 2 - 210, 190, 420, 400), PANEL)
        draw_text(self.screen, title, FONT_LARGE, WHITE, (WIDTH // 2, 252))
        if subtitle:
            draw_text(self.screen, subtitle, FONT_SMALL, MUTED, (WIDTH // 2, 298))

    def draw_pause(self):
        self.draw_overlay(tr("PAUSED", "暫停"), tr("MISSION CONTROL // LINK STABLE", "任務控制中心 // 連線穩定"))

    def draw_gameover(self):
        self.draw_overlay(tr("SHIP LOST", "飛船失聯"),
                          tr(f"WAVE {self.session.wave}  //  SCORE {self.session.score:,}",
                             f"第 {self.session.wave} 波  //  分數 {self.session.score:,}"))

    def draw_levelup(self):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((2, 7, 20, 210))
        self.screen.blit(overlay, (0, 0))
        draw_text(self.screen, tr("SYSTEM UPGRADE", "系統升級"), FONT_LARGE, YELLOW, (WIDTH // 2, 138))
        draw_text(self.screen, tr(
            f"PILOT LEVEL {self.session.player.level}  //  PICK 1 OF {len(self.session.choices)}",
            f"駕駛員等級 {self.session.player.level}  //  {len(self.session.choices)} 選 1"),
                  FONT_SMALL, WHITE, (WIDTH // 2, 190))
        mouse = pygame.mouse.get_pos()
        for index, (upgrade, rect) in enumerate(zip(self.session.choices, self.upgrade_rects())):
            hovered = rect.collidepoint(mouse)
            color = YELLOW if hovered else CYAN
            draw_panel(self.screen, rect, PANEL_LIGHT if hovered else PANEL, color, 16)
            draw_text(self.screen, f"0{index + 1}", FONT_MEDIUM, color, (rect.centerx, rect.y + 48))
            words = upgrade.name.split()
            title = upgrade.name_zh if get_language() == "zh" else " ".join(words[:2])
            draw_text(self.screen, title, FONT, WHITE, (rect.centerx, rect.y + 105))
            if len(words) > 2 and get_language() == "en":
                draw_text(self.screen, " ".join(words[2:]), FONT, WHITE, (rect.centerx, rect.y + 134))
            desc = upgrade.description_zh if get_language() == "zh" else upgrade.description
            draw_text(self.screen, desc, FONT_SMALL, MUTED, (rect.centerx, rect.y + 183))
            draw_text(self.screen, tr("CLICK TO INSTALL", "點擊選擇"), FONT_SMALL, color,
                      (rect.centerx, rect.bottom - 34))
